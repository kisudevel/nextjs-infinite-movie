import banner_bg01 from "./banner_bg01.jpg";
import thumbnail01 from "./thumbnail01.jpg";
import thumbnail02 from "./thumbnail02.png";
import star from "./star.svg";
export { banner_bg01, thumbnail01, thumbnail02, star };
